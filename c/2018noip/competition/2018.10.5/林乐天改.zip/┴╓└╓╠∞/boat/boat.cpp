#include <stdio.h>
#include <algorithm>
#include<string.h>
using namespace std;
int a[210][210];
int main()
{
	freopen("boat.in","r",stdin);
	freopen("boat.out","w",stdout);
	int n;
	scanf("%d", &n);
	memset(a, 0x3f, sizeof(a));
	for (int i = 0; i < n - 1; i++)
	{
		int j;
		for (j = 0; j < n - i - 1; j++)
		{
			scanf("%d", &a[i][j]);
			a[n - j - 1][n - i - 1] = a[i][j];
		}	
	}
	for(int i = 0;i  <n;i++)
	{
		a[i][n - i - 1] = 0;
	}
	for(int k = 0 ;k < n;k++)
	{
		for(int i = 0;i < n;i++)
		{
			for(int j = 0;j < n;j++)
			{
				a[i][j] = min(a[i][j], a[i][k] + a[k][j]);
			}
		}
	}
	printf("%d",a[0][n - 1]);
	return 0;
}
