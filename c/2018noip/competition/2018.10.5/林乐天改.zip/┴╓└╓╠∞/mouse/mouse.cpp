#include <stdio.h>
#include <algorithm>
#include <queue>
using namespace std;
struct aa
{
	int x, y;
	int val;
} a;
queue<aa> q;
int dy[4] = {-1, 0, 1, 0}, dx[] = {0, -1, 0, 1};
char map[90][90];
int main()
{
	freopen("mouse.in","r",stdin);
	freopen("mouse.out","w",stdout);
	int n, m;
	bool flag = false;
	scanf("%d%d", &n, &m);
	for (int i = 0; i < n; i++)
	{
		scanf("%s", map[i]);
		if (!flag)
			for (int j = 0; j < m; j++)
			{
				if (map[i][j] == 'R')
				{
					a.x = i;
					a.y = j;
					a.val = 0;
					q.push(a);
					flag = true;
					break;
				}
			}
	}
	int x, y, val = 0;
	flag = false;
	while (!q.empty())
	{
		x = q.front().x;
		y = q.front().y;
		val = q.front().val + 1;
		for (int i = 0; i < 4; i++)
		{
			if(map[x][y] == 'B') break;
			if (x + dx[i] < m && x + dx[i] >= 0 && y + dy[i] < n && y + dy[i] >= 0 && map[x + dx[i]][y + dy[i]] != 'B')
			{
				a.val = val;
				a.x = x + dx[i];
				a.y = y + dy[i];
				q.push(a);
			}
			if (map[x + dx[i]][y + dy[i]] == 'F' && x + dx[i] < n && x + dx[i] >= 0 && y + dy[i] < m && y + dy[i] >= 0)
			{
				printf("(%d,%d) %d\n",y + dy[i] + 1,x + dx[i] + 1,val);
				flag = true;
			}
		}
		map[x][y] = 'B';
		q.pop();
	}
	if(!flag)
		printf("-1");
	return 0;
}
