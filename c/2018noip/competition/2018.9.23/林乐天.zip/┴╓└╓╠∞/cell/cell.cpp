#include<stdio.h>
int main()
{
	freopen("cell.in","r",stdin);
	freopen("cell.out","w",stdout);
	int N;
	int m,n;
	scanf("%d",&N);
	if(N == 2) printf("2");
	printf("-1");
}
