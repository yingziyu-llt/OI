#include<stdio.h>
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	printf("5");
	return 0;
}
