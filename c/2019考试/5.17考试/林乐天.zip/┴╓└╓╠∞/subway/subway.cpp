#include<stdio.h>
#include<algorithm>
using namespace std;

int main()
{
	freopen("subway.out","w",stdout);
	printf("0");
	fclose(stdout);
}