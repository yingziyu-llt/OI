#include<stdio.h>
int main()
{
	int m;
	scanf("%d",&m);
	int ans = 0;
	int n;
	scanf("%d",&)
	for(int i = 0;i < m;i++)
	{
		int h,v;
		scanf("%d%d",&h,&v);
		m
	}
}