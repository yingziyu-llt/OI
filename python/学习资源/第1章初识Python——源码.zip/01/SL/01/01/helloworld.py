print("人生苦短，我用Python")
