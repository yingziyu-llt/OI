coffeename = ('蓝山','卡布奇诺','曼特宁','摩卡','麝香猫','哥伦比亚')   # 定义元组
print(coffeename)                                                    # 输出元组


