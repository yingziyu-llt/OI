coffeename = ('蓝山','卡布奇诺','曼特宁','摩卡','麝香猫','哥伦比亚')   # 定义元组
print("您好，欢迎光临 ~ 伊米咖啡馆 ~\n\n我店有：\n")
for name in coffeename:                                              #遍历元组
    print(name + "咖啡",end = " ")

