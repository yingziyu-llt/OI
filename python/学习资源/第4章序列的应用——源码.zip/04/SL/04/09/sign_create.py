name = ['绮梦','冷伊一','香凝','黛兰']        # 作为键的列表
sign = ['水瓶座','射手座','双鱼座','双子座']  # 作为值的列表
dictionary = dict(zip(name,sign))            # 转换为字典
print(dictionary)                              # 输出转换后字典
