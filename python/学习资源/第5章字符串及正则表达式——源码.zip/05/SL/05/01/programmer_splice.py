programmer_1 = '程序员甲：搞IT太辛苦了，我想换行……怎么办？'    # 程序员甲说的话
programmer_2 = '程序员乙：敲一下回车键'                    # 程序员乙说的话
print(programmer_1 + '\n\n' + programmer_2)        # 拼接后输出
