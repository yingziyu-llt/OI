﻿import bmi                     # 导入bmi模块
bmi.fun_bmi("尹一伊",175,120)  # 执行模块中的fun_bmi()方法

# 在导入模块时设置别名的应用
# import bmi as m                     # 导入bmi模块
# m.fun_bmi("尹一伊",175,120)  # 执行模块中的fun_bmi()方法
